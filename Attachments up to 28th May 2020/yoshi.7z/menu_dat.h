//======================================================
//    menu_dat.h
//    Header for Menu Data of Sample Yoshi
//
//    Copyright (C) 1999-2000 NINTENDO Co.,Ltd.
//======================================================

#ifndef MENU_DAT_H
#define MENU_DAT_H
extern const u16 p0_yoshi_island_Palette[256];
extern const u8 *p0_isle_tbl[];
extern const u8 p0_size_tbl[];
extern const u8 *p0_map_tbl[];
#endif
