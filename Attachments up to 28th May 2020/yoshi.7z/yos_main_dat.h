//======================================================
//    yos_main_dat.h
//    Sample Yoshi Data Header
//
//    Copyright (C) 1999-2000 NINTENDO Co.,Ltd.
//======================================================

#ifndef YOS_MAIN_DAT_H
#define YOS_MAIN_DAT_H

extern const s16 fix_sin[];
extern const s16 fix_cos[];

#endif
